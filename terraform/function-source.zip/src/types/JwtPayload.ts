export type JwtPayload = {
  id: number;
  name: string;
  email: string;
  created_at: Date;
};
